====
Introduction to NoTex.ch - の紹介
====

The online text editor NoTex.ch_ allows you to write articles, but, reports and complex theses. Thanks to the *easy to use* markup language **reStructuredText** (rST)\ [1]_ you write the content once and then export it to PDF, HTML or even LaTex.

オ ンラインテキストエディタ NoTex.ch_ は記事を 書くことができますが、レポートや複雑な論文はでき ません。マークアップランゲイジ **reStructuredText** (rST)\ [1]_ を使用 することによって、内容を作成し PDF, HTML, LaTexにエクスポートできま す。

.. _NoTex.ch: https://notex.ch

The **PDF** is of publication quality and can directly be submitted to scientific conferences; using the **HTML** you can immediately improve your online presence; and people who like to use **LaTex** can continue doing so by simply clicking on the corresponding export button.

**PDF** は出版品質のものであり、直接科学会議に提 出することができます。
**HTML** を使用すると、あなたのオンラインプレゼ ンスを向上することができます。また **LaTex** を使用し たい人は、簡単にエクスポートボタンを継続してクリック することができます。

Since NoTex.ch_ is an online tool, there is no need for installation or maintenance. With the integrated *project management* you can create content consisting of multiple interrelated documents, which can be organized into folders and sub-folders. The projects can be exported and re-imported back as **ZIP** archives.

NoTex.ch_ がオンラインツールであるために、インストールまたはメンテナンスをする必要がありません。総合されたプロジェクト管理で、あなたはフォルダ とサブフォルダに整理されたもの、複数の相互関連文書か ら成る内容を作成することができます。プロジェクトはエ クスポートできますし、**ZIP** 公文書として再度インポートできます。

In addition to rST, the editor supports syntax highlighting for the **Markdown**\ [2]_ markup and many more languages: LaTex, C, C++, Java, Python, PHP, SQL, Json and YAML are only a few of them!

rSTに加えて、編集者はマークダウンのマーク アップと、より多くの言語： LaTex, C, C++, Java, Phython, PHP, SQL, Json, YAML のための構文の強調表示を維持しています。

Learning rST or Markdown is *easy* since on one hand they have been specifically designed so and on the other hand NoTex.ch_ offers self explanatory *toolbars* which you can use to write your content with. 

rSTやマークダウンを学ぶことは簡単です。NoTex.ch_ はあなたが内容を書き込むために、自己説明のツール バーを使用することができます。

.. figure:: logo.png
   :scale: 50 %
   :align: center

   NoTex.ch_ Logo

This text itself is written in rST and consists of a heading, multiple paragraphs which contain regular, italic and bold text (for weak and strong emphasis), a figure (with a caption), two footnotes, and three hyperlinks (one in the main text, which is referred to multiple times, and two in the footnotes).

このテキスト自体はrSTで書かれており、また見 出しが構成されており、多様なパラグラフは定期的に斜体 や太字テキスト（弱い強調と強い強調）、キャプション付 きの図、２つの列挙された脚注および３つのハイパーリン ク（本文中はリンクが１つ、脚注はリンクが２つ）で複数 構成されています。


.. [1] See https://en.wikipedia.org/wiki/ReStructuredText for further information on reStructuredText.

.. [2] See https://en.wikipedia.org/wiki/Markdown offers additional information on Markdown.

