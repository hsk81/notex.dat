Introduction to NoTex.ch
========================

The online text editor NoTex.ch_ allows you to write articles, reports and complex theses. Thanks to the *easy to use* markup language **reStructuredText** (rST) [#]_ you write the content once and then export it to PDF, HTML or even LaTex.

.. _NoTex.ch: https://notex.ch

The **PDF** is of publication quality and can directly be submitted to scientific conferences; using the **HTML** you can immediately improve your online presence; and people who like to use **LaTex** can continue doing so by simply clicking on the corresponding export button.

Since NoTex.ch_ is an online tool, there is no need for installation or maintenance. With the integrated *project management* you can create content consisting of multiple interrelated documents, which can be organized into folders and sub-folders. The projects can be exported and re-imported back as **ZIP** archives.

In addition to rST, the editor supports syntax highlighting for the **Markdown** [#]_ markup and many more languages: LaTex, C, C++, Java, Python, PHP, SQL, Json and YAML are only a few of them!

Learning rST or Markdown is *easy* since on one hand they have been specifically designed so and on the other hand NoTex.ch_ offers self explanatory *toolbars* which you can use to write your content with. 

.. figure:: logo.png
   :scale: 50 %
   :align: center

   NoTex.ch_ Logo

This text itself is written in rST and consists of a heading, multiple paragraphs which contain regular, italic and bold text (for weak and strong emphasis), a figure (with a caption), two *auto enumerated* footnotes, and three hyperlinks (one in the main text, which is referred to multiple times, and two in the footnotes).

.. [#] See https://en.wikipedia.org/wiki/ReStructuredText for further information on reStructuredText.

.. [#] See https://en.wikipedia.org/wiki/Markdown offers additional information on Markdown.