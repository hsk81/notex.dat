Introduction to NoTex.ch
========================

The online text editor NoTex.ch_ allows you to write articles, but, reports and complex theses. Thanks to the *easy to use* markup language **reStructuredText** (rST)\ [#]_ you write the content once and then export it to PDF, HTML or even LaTex.

オンラインテキストエディタ NoTex.ch_ は、あなたが記事を書くことができますが、レポートや複雑な論文。マークアップを使用して簡単に感謝言語 **reStructuredText** のRST）は\ [#]_、一度コンテンツを作成し、その後、PDF、HTML、あるいはラテックスにエクスポートします。


.. _NoTex.ch: https://notex.ch

The **PDF** is of publication quality and can directly be submitted to scientific conferences; using the **HTML** you can immediately improve your online presence; and people who like to use **LaTex** can continue doing so by simply clicking on the corresponding export button.

**PDF** には、出版品質のものであり、直接に提出することができます科学会議、 **HTML** を使用すると、すぐに向上させることができますあなたのオンラインプレゼンス、およびラテックスを使用したい人は、缶単に対応するエクスポートをクリックして、そうすることを続けるボタンを押します。

Since NoTex.ch_ is an online tool, there is no need for installation or maintenance. With the integrated *project management* you can create content consisting of multiple interrelated documents, which can be organized into folders and sub-folders. The projects can be exported and re-imported back as **ZIP** archives.

NoTex.ch_ がオンラインツールであるため、インストール又はする必要がないメンテナンス。統合*プロジェクト管理と*あなたが作成することができます可能な複数の相互に関連の文書からなるコンテンツ、フォルダとサブ·フォルダに整理。プロジェクトは、エクスポートすることができますおよび **ZIP** アーカイブとしてバック再インポート。

In addition to rST, the editor supports syntax highlighting for the **Markdown**\ [#]_ markup and many more languages: LaTex, C, C++, Java, Python, PHP, SQL, Json and YAML are only a few of them!

**RST** に加えて、編集者はのための構文の強調表示をサポートしていますマークダウン\ [#]_ のマークアップと、より多くの言語：ラテックス、 C、C++、Javaの、Pythonや、PHP、SQL、JSONと、YAMLは、それらのほんの一部です！

Learning rST or Markdown is *easy* since on one hand they have been specifically designed so and on the other hand NoTex.ch_ offers self explanatory *toolbars* which you can use to write your content with. 

一方では、彼らがされているため、RSTまたはマークダウンを学ぶことは簡単です特にそのようにし、他方で設計された NoTex.ch_ 自己を提供していますあなたとあなたのコンテンツを書き込むために使用できるツールバーを説明のため。

.. figure:: logo.png
   :scale: 50 %
   :align: center

   NoTex.ch_ Logo

This text itself is written in rST and consists of a heading, multiple paragraphs which contain regular, italic and bold text (for weak and strong emphasis), a figure (with a caption), two *auto enumerated* footnotes, and three hyperlinks (one in the main text, which is referred to multiple times, and two in the footnotes).

このテキスト自体はRSTで書かれており、見出し、複数で構成されている定期的に、斜体や太字テキスト（弱いためとが含まれている段落強い強調）、キャプション付きの図、 2オート列挙さ脚注、および3のハイパーリンク（本文中1 、これは複数回呼ばれ、脚注は二つ)。

.. [#] See https://en.wikipedia.org/wiki/ReStructuredText for further information on reStructuredText.

.. [#] さらに用 `ReStructuredText <http://en.wikipedia.org/wiki/ReStructuredText>`_ を参照してください。reStructuredTextの情報。

.. [#] See https://en.wikipedia.org/wiki/Markdown offers additional information on Markdown.

.. [#] `Markdown <https://en.wikipedia.org/wiki/Markdown>`_、追加提供しています参照してくださいマークダウンの情報。